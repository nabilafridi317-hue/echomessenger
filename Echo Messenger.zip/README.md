# Echo Messenger — front-end prototype

A responsive HTML/CSS/JavaScript messenger interface with browser-local message storage, offline shell caching, local photo/video attachments, voice recording, contact creation, export, and audio/video call UI previews.

## Run it

Service workers generally require `localhost` or HTTPS. Do not open `index.html` directly if you want the offline app shell to install.

1. Extract this folder.
2. Open a terminal in the folder.
3. Run a local server, for example:
   - Python: `python -m http.server 8000`
   - Node: `npx serve .`
4. Visit `http://localhost:8000`.

## Important limitations

This is a front-end demo, not a production messaging service:
- Messages are saved in the current browser's `localStorage`; they do not reach other users or devices.
- Offline mode can show local history and queue messages only on this device. It cannot deliver while disconnected; syncing requires a backend when the device reconnects.
- Account creation is only a UI preview. Email verification, SMS OTP, sessions, and password security require an authentication provider/backend.
- Audio/video buttons show a call UI preview only. Real calls require WebRTC, signaling, STUN/TURN configuration, and a backend.
- Large media files may exceed browser storage limits. This demo limits selected attachments to 8 MB but localStorage itself has a small quota; use IndexedDB for media and a server/object store for production.
- The service worker caches the app shell for offline opening; run through localhost/HTTPS.

## Suggested production stack

- Authentication: Supabase Auth or Firebase Authentication (email and phone OTP)
- Messaging and presence: Supabase Realtime/Postgres or Firebase
- Media storage: Supabase Storage or Firebase Storage
- Calls: WebRTC with a signaling service and STUN/TURN servers
- Offline persistence: IndexedDB (for example, Dexie) with an outgoing message queue and conflict-safe synchronization
- Security: access rules, server-side validation, rate limits, secure media access, and end-to-end encryption design if required
